import os

# Pure-Python MySQL driver (easy to install on Windows). Only used when DB_ENGINE=mysql.
if os.environ.get("DB_ENGINE") == "mysql":
    import pymysql

    pymysql.install_as_MySQLdb()
