# macOS / Linux:  source database/set_mysql_env.sh
export DB_ENGINE=mysql DB_NAME=hms_db DB_USER=hms_user DB_PASSWORD='Hms@12345' DB_HOST=127.0.0.1 DB_PORT=3306
echo "MySQL environment set for this terminal."
