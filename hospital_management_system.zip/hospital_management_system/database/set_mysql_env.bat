@echo off
REM Windows: run this in the same terminal before manage.py commands.
set DB_ENGINE=mysql
set DB_NAME=hms_db
set DB_USER=hms_user
set DB_PASSWORD=Hms@12345
set DB_HOST=127.0.0.1
set DB_PORT=3306
echo MySQL environment set for this terminal.
