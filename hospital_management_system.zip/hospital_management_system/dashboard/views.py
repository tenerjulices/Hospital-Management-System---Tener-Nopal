from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from accounts.models import CustomUser
from admissions.models import Admission
from core.decorators import admin_required, super_admin_required
from core.models import ActivityLog
from patients.models import Patient
from reports import services


@login_required
def home(request):
    """Send each role to its own dashboard."""
    if request.user.is_super_admin:
        return redirect("dashboard:super_admin")
    return redirect("dashboard:admin")


@super_admin_required
def super_admin_dashboard(request):
    return render(request, "dashboard/super_admin.html", {
        "stats": services.headline_stats(),
        "charts": {
            "monthly": services.registrations_by_month(6),
            "gender": services.gender_breakdown(),
        },
        "recent_patients": Patient.objects.filter(is_archived=False).select_related("registered_by")[:6],
        "recent_activities": ActivityLog.objects.select_related("user")[:8],
        "recent_admins": CustomUser.objects.filter(role=CustomUser.Role.ADMIN).order_by("-created_at")[:5],
    })


@admin_required
def admin_dashboard(request):
    return render(request, "dashboard/admin.html", {
        "stats": services.headline_stats(),
        "charts": {
            "daily": services.registrations_by_day(7),
            "status": services.status_breakdown(),
        },
        "recent_patients": Patient.objects.filter(is_archived=False).select_related("registered_by")[:6],
        "recent_activities": ActivityLog.objects.filter(user=request.user)[:8],
        "current_admissions": Admission.objects.filter(discharge_date__isnull=True)
                              .select_related("patient")[:5],
        "my_registered": Patient.objects.filter(registered_by=request.user, is_archived=False).count(),
    })
